from Infrastructure import Logger, Config, Resolver
from Global import Core

Core.Logger = Logger.Logger()
Core.Config = Config.Config()
Core.Resolver = Resolver.Resolver()
